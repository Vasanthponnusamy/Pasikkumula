from django.http import HttpResponse
from django.template import loader




def app(request):
    return HttpResponse("hello django!!!")

def index(request):
    template = loader.get_template('index.html')
    return HttpResponse(template.render())

def services(request):
    template = loader.get_template('services.html')
    return HttpResponse(template.render())

def footer(request):
    template = loader.get_template('footer.html')
    return HttpResponse(template.render())

def header(request):
    template = loader.get_template('header.html')
    return HttpResponse(template.render())

def about(request):
    template = loader.get_template('about.html')
    return HttpResponse(template.render())

def contact(request):
    template = loader.get_template('contact.html')
    return HttpResponse(template.render())

def products(request):
    template = loader.get_template('products.html')
    return HttpResponse(template.render())