from django.contrib import admin

from .models import kk,jj
from .models import *

admin.site.register(kk)
admin.site.register(jj)
admin.site.register(Customer)
admin.site.register(Product)
admin.site.register(Product1)
admin.site.register(Order)
admin.site.register(OrderItem)
admin.site.register(ShippingAddress)

# Register your models here.
