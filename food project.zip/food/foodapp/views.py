from django.shortcuts import render, redirect
from django.http import HttpResponse
from django.template import loader
from .models import jj
from .models import *
from django.http import JsonResponse
import json
from django.db import models


def home(request):
    return HttpResponse("Hello, Django!")


def index(request):
    template = loader.get_template('index.html')
    return HttpResponse(template.render())


def booktable(request):

    mydata = jj.objects.all()

    if (mydata != ""):
        return render(request, "booktable.html", {"datas": mydata})
    else:
        return render(request, "booktable.html")


def order(request):
    template = loader.get_template('order.html')
    return HttpResponse(template.render())


def contact(request):
    template = loader.get_template('contact.html')
    return HttpResponse(template.render())


def about(request):
    template = loader.get_template('about.html')
    return HttpResponse(template.render())


def order(request):
    ctx = {'active_link': 'order'}
    return render(request, 'order.html', ctx)


def menu(request):

    if request.user.is_authenticated:
        customer = request.user.customer
        order, created = Order.objects.get_or_create(
            customer=customer, complete=False)
        items = order.orderitem_set.all()
        cartItems = order.get_cart_items
    else:
        items = []
        order = {'get_card_total': 0, 'get_card_items': 0, 'shipping': False}
        cartItems = order['get_cart_items']

    products = Product.objects.all()
    

    context = {'products': products,
               'cartItems': cartItems }
    return render(request, 'menu.html', context)



def cart(request):
    if request.user.is_authenticated:
        customer = request.user.customer
        order, created = Order.objects.get_or_create(
            customer=customer, complete=False)
        items = order.orderitem_set.all()
        cartItems = order.get_cart_items
    else:
        items = []
        order = {'get_card_total': 0, 'get_card_items': 0, 'shipping': False}
        cartItems = order['get_cart_items']

    context = {'items': items, 'order': order, 'cartItems': cartItems}
    return render(request, 'cart.html', context)


def checkout(request):
    if request.user.is_authenticated:
        customer = request.user.customer
        order, created = Order.objects.get_or_create(
            customer=customer, complete=False)
        items = order.orderitem_set.all()
        cartItems = order.get_cart_items
    else:
        items = []
        order = {'get_card_total': 0, 'get_card_items': 0, 'shipping': False}
        cartItems = order['get_cart_items']
    context = {'items': items, 'order': order, 'cartItems': cartItems}
    return render(request, 'checkout.html', context)






def updateItem(request):
    data = json.loads(request.body)
    ProductId = data['productId']
    action = data['action']

    print('Action:', action)
    print('ProductId:', ProductId)

    customer = request.user.customer
    product = Product.objects.get(id=ProductId)

    order, created = Order.objects.get_or_create(
        customer=customer, complete=False)

    orderItem, created = OrderItem.objects.get_or_create(
        order=order, product=product)

    if action == 'add':
        orderItem.quantity = (orderItem.quantity + 1)
    elif action == 'remove':
        orderItem.quantity = (orderItem.quantity - 1)

    orderItem.save()

    if orderItem.quantity <= 0:
        orderItem.delete()

    if 'product1Id' in data:
        Product1Id = data['product1Id']
        # Retrieve the associated product1 or perform operations with it

    return JsonResponse('Items were added', safe=False)




def addData(request):
    if request.method == "POST":
        name = request.POST["name"]
        age = request.POST["age"]
        contact = request.POST["contact"]
        address = request.POST["address"]
        mail = request.POST["mail"]

        obj = jj()
        obj.Name = name
        obj.Age = age
        obj.Contact = contact
        obj.Address = address
        obj.Mail = mail
        obj.save()

        mydata = jj.objects.all()
        return redirect("booktable")

    return render(request, "booktable.html")


def updateData(request, id):
    mydata = jj.objects.get(id=id)

    if request.method == "POST":
        name = request.POST["name"]
        age = request.POST["age"]
        contact = request.POST["contact"]
        address = request.POST["address"]
        mail = request.POST["mail"]

        mydata.Name = name
        mydata.Age = age
        mydata.Contact = contact
        mydata.Address = address
        mydata.Mail = mail
        mydata.save()

        return redirect("booktable")

    return render(request, "update.html", {"data": mydata})


def deleteData(request, id):
    mydata = jj.objects.get(id=id)
    mydata.delete()
    return redirect("booktable")


# Create your views here.
